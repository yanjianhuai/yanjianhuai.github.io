package com.example.yangrongni.game;

public class DataHelper {
	
	public static  int number[] = new int[]{1,2,3,4,8,5,7,6,0};

}
